A shortcut to the new Toolbox project has been placed on your desktop.
Its icon looks like an open toolbox. Its name is "Toolbox Project".

