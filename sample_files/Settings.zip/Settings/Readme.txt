This installs the files needed for a new Toolbox project.
This package is Toolbox New Project version 1.5.0 Aug 2006.

